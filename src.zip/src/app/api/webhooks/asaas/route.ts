import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabaseAdmin";

export const dynamic = "force-dynamic";

// Asaas envia eventos de pagamento. Protegido por token (header asaas-access-token
// ou ?token=). Casa o pagamento ao tenant por asaas_subscription_id/customer_id.
export async function POST(req: Request) {
  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: "billing não configurado" }, { status: 500 });

  const expected = process.env.ASAAS_WEBHOOK_TOKEN;
  const url = new URL(req.url);
  const token = req.headers.get("asaas-access-token") || url.searchParams.get("token");
  if (!expected) {
    // fail-closed: sem o token configurado, não processa nada (evita PAYMENT_CONFIRMED forjado)
    return NextResponse.json({ error: "ASAAS_WEBHOOK_TOKEN não configurado" }, { status: 503 });
  }
  if (token !== expected) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "payload inválido" }, { status: 400 });
  }

  const event = body?.event as string | undefined;
  const payment = body?.payment || {};
  const subId = payment?.subscription as string | undefined;
  const custId = payment?.customer as string | undefined;
  const payId = payment?.id as string | undefined;
  const dueDate = payment?.dueDate as string | undefined;
  const value = Number(payment?.value) || 0;
  const invoiceUrl = (payment?.invoiceUrl || payment?.bankSlipUrl) as string | undefined;
  const description = payment?.description as string | undefined;

  if (!event) return NextResponse.json({ ok: true, ignored: "sem evento" });

  // 1) casa uma FATURA da central por asaas_payment_id (fluxo link de pagamento)
  if (payId) {
    const { data: inv } = await admin.from("platform_invoices").select("id, tenant_id, payment_link").eq("asaas_payment_id", payId).maybeSingle();
    if (inv) {
      if (event === "PAYMENT_CREATED") {
        // fatura já existe na central: garante o link salvo (caso tenha nascido sem link)
        if (invoiceUrl && !(inv as any).payment_link) {
          await admin.from("platform_invoices").update({ payment_link: invoiceUrl }).eq("id", (inv as any).id);
        }
        // régua pró-ativa: avisa o cliente que a fatura foi criada (com o link)
        await import("@/lib/dunning").then((m) => m.sendInvoiceCreated(admin, (inv as any).id)).catch(() => {});
        return NextResponse.json({ ok: true, event, invoice: (inv as any).id, note: "link garantido" });
      }
      if (event === "PAYMENT_CONFIRMED" || event === "PAYMENT_RECEIVED") {
        await admin.from("platform_invoices").update({ status: "paid", paid_at: new Date().toISOString() }).eq("id", (inv as any).id);
        // M4: pagamento tardio de um tenant JÁ CANCELADO (sem assinatura ativa) NÃO
        // ressuscita a conta. Só reativa se ainda houver assinatura vinculada.
        const { data: tRow } = await admin.from("tenants").select("asaas_subscription_id").eq("id", (inv as any).tenant_id).maybeSingle();
        if ((tRow as any)?.asaas_subscription_id) {
          const base = dueDate ? new Date(dueDate) : new Date();
          base.setMonth(base.getMonth() + 1);
          await admin.from("tenants").update({ subscription_status: "active", current_period_end: base.toISOString().slice(0, 10), suspended_at: null, archived_at: null, ...(value ? { mrr: value } : {}) }).eq("id", (inv as any).tenant_id);
          // reseta a régua de cobrança: pagou → pode disparar de novo num próximo atraso
          await admin.from("business_message_sends").delete().eq("tenant_id", (inv as any).tenant_id);
        }
      } else if (event === "PAYMENT_OVERDUE") {
        await admin.from("platform_invoices").update({ status: "overdue" }).eq("id", (inv as any).id);
        await admin.from("tenants").update({ subscription_status: "past_due" }).eq("id", (inv as any).tenant_id);
      }
      return NextResponse.json({ ok: true, event, invoice: (inv as any).id });
    }

    // 1b) PAYMENT_CREATED de cobrança que NÃO existe na central (ex.: assinatura recorrente
    //     gerou a fatura do mês no Asaas) → cria o registro casando pelo cliente.
    if (event === "PAYMENT_CREATED" && custId) {
      const { data: t } = await admin.from("tenants").select("id").eq("asaas_customer_id", custId).maybeSingle();
      if (t) {
        // M3: upsert idempotente — se o action de assinar já criou esta fatura, não duplica
        await admin.from("platform_invoices").upsert({
          tenant_id: (t as any).id,
          amount: value,
          description: description || "Assinatura Contatia",
          due_date: dueDate || null,
          payment_link: invoiceUrl || null,
          asaas_payment_id: payId,
          asaas_subscription_id: subId || null,
          status: "pending",
        }, { onConflict: "asaas_payment_id", ignoreDuplicates: true });
        // régua pró-ativa: avisa o cliente que a fatura foi criada (com o link)
        const { data: created } = await admin.from("platform_invoices").select("id").eq("asaas_payment_id", payId).maybeSingle();
        if (created) await import("@/lib/dunning").then((m) => m.sendInvoiceCreated(admin, (created as any).id)).catch(() => {});
        return NextResponse.json({ ok: true, event, note: "fatura criada a partir do Asaas" });
      }
    }
  }

  // localiza o tenant
  let q = admin.from("tenants").select("id");
  if (subId) q = q.eq("asaas_subscription_id", subId);
  else if (custId) q = q.eq("asaas_customer_id", custId);
  else return NextResponse.json({ ok: true, ignored: "sem assinatura/cliente" });
  const { data: tenant } = await q.maybeSingle();
  if (!tenant) return NextResponse.json({ ok: true, ignored: "tenant não encontrado" });

  const tid = (tenant as any).id;
  const patch: any = {};

  if (event === "PAYMENT_CONFIRMED" || event === "PAYMENT_RECEIVED") {
    patch.subscription_status = "active";
    if (value) patch.mrr = value;
    // estende o período ~1 mês a partir do vencimento pago
    const base = dueDate ? new Date(dueDate) : new Date();
    base.setMonth(base.getMonth() + 1);
    patch.current_period_end = base.toISOString().slice(0, 10);
  } else if (event === "PAYMENT_OVERDUE") {
    patch.subscription_status = "past_due";
  } else if (event === "PAYMENT_DELETED" || event === "SUBSCRIPTION_DELETED") {
    patch.subscription_status = "canceled";
  } else {
    return NextResponse.json({ ok: true, ignored: event });
  }

  await admin.from("tenants").update(patch).eq("id", tid);
  return NextResponse.json({ ok: true, event, tenant: tid });
}
